##############################################
### ORSYP PS - 2013
### Ths script is to be used within a Resource of type "Script"
### It counts the number of jobs in "Running" Status and matches it to a limit passed as a parameter
###
### $1: [Mandatory] => Upper limit (if it is always reached, the resource will not allow a job to run)
### $2: [Optional] => Nodename (local node if not specified)
###
##############################################

The two packages contain the following objects:

1- (Administration Object Package) sh script that will be inserted on the agent as a nodefile, in charge of checking the number of running jobs
2- (Regular Package) the Dollar Universe resource which calls the script (see point 1) in order to assess whether another job should run


Installation:

	Insert both packages into Dollar Universe

Usage:

	Edit the inserted resource in order to fill out parameters for the script (by default there is only one parameter with value of 2)

	Parameter 1: [mandatory] Upper limit for number of current running jobs (if the actual number is above the limit, the resource stays in event wait)
	Parameter 2: [Optional], remote node name (if unspecified, the node name used is the local one)
